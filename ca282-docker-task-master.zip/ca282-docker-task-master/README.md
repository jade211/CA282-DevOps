# CA282 docker task

Fork and clone this repo.

There are two tasks.  See the relevant directories in this directory:

- Task 1 is worth 30 marks.
- Task 2 is worth either 30 or 70 marks (depending upon the approach you take).

When you are done, commit your work and push it back to your own project on GitLab.

I (SB) will collect your work from there.
