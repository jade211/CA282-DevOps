#!/bin/bash

# #########################################################
# The "test" command will be different depending upon the approach
# you take.
#
# Add whatever commands test your container configuration here.
#
# This file is called by `make test`.
#

# docker network create container_network
# docker network connect container_network container_1
# docker network connect container_network container_2

docker exec -it container_2 wget -q -O - container_1/index.html


