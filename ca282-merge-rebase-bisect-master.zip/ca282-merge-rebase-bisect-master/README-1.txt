There are two additional branches in this repo: "subtract" and "multiply".

Merge both of those branches into this "master" branch, and push the result
to origin/master.

You will encounter a merge conflict, and you will have to resolve it.

The resulting version of the arithmetic.py should include the add(),
subtract() and multiply() functions, and test cases for each function.

Note
----

This is a Python2 implementation:

   $ python2 arithmetic.py

Or perhaps:

   $ python2.7 arithmetic.py

Or, if python2 is the default version of Python, then just:

   $ python arithmetic.py

------------------------------------------------------------------------

When you are done, read README-2.txt.
