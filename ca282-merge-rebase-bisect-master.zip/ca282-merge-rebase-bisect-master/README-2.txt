Checkout the branch named "divide", and read the README file there.
