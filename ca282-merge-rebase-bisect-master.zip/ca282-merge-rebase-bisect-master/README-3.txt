Checkout the branch named "square", and read the README file there.
