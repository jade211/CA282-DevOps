This branch contains and implementation of the multiply() function.

Merge it into master.
