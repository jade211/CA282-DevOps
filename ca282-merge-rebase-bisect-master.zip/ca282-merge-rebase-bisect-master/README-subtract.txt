This branch contains and implementation of the subtract() function.

Merge it into master.
