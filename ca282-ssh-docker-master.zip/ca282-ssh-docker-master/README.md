SSH task repo for CA282.

For tasks, see the READMEs in individual subdirectories.
