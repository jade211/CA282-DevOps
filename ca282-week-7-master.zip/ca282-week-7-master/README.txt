Test repo for CA282 week 7.

Fork on GitLab and clone your repo locally.

See the file bin/hash.sh.

There, uncomment the three indicated lines.

Commit that, and push it back to GitLab.

Count to ten, then visit *your* GitLab project, and visit

   "CI/CD" -> "Jobs"

from the menus on the left-hand side.

You should see the result of running your script on the GitLab
CI server, which should reveal your personal hash.

Take that hash and upload it to Einstein, as instructed on the
lab sheet.
